// Mobile menu
const btn=document.querySelector('.menu-btn'),links=document.getElementById('links');
btn.addEventListener('click',()=>{const o=links.classList.toggle('open');btn.setAttribute('aria-expanded',o)});
links.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>links.classList.remove('open')));

// Active nav link on scroll
const secs=[...document.querySelectorAll('main section[id]')];
const nav=[...links.querySelectorAll('a')];
new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){nav.forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#'+e.target.id))}}),{rootMargin:'-45% 0px -50% 0px'}).observe&&secs.forEach(s=>new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)nav.forEach(a=>a.classList.toggle('on',a.getAttribute('href')==='#'+s.id))}),{rootMargin:'-45% 0px -50% 0px'}).observe(s));

// Photo: use photo.jpg if present, else upload & remember in browser
const img=document.getElementById('photoImg'),hint=document.getElementById('photoHint'),input=document.getElementById('photoInput');
function show(src){img.src=src;img.hidden=false;hint.hidden=true}
try{const s=localStorage.getItem('rp_photo');if(s)show(s)}catch(e){}
const probe=new Image();probe.onload=()=>{if(img.hidden)show('photo.jpg')};probe.src='photo.jpg';
input.addEventListener('change',()=>{const f=input.files[0];if(!f)return;const r=new FileReader();
 r.onload=()=>{show(r.result);try{localStorage.setItem('rp_photo',r.result)}catch(e){}};r.readAsDataURL(f)});
document.getElementById('photo').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();input.click()}});
